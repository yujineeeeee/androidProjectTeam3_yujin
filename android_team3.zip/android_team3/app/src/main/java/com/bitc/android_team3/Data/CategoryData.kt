package com.bitc.android_team3.Data

import com.google.gson.annotations.SerializedName

data class CategoryData(val cd:String, val name:String, val jeongGa:Int, val discount: Int, val price:Int, val img:String, val imgBig:String)
