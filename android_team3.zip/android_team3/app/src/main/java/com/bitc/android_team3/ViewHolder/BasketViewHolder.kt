package com.bitc.android_team3.ViewHolder

import androidx.recyclerview.widget.RecyclerView
import com.bitc.android_team3.databinding.CalendarTextBinding

class BasketViewHolder(val binding: CalendarTextBinding): RecyclerView.ViewHolder(binding.root)









