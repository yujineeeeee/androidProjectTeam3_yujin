package com.bitc.android_team3.ViewHolder

import androidx.recyclerview.widget.RecyclerView
import com.bitc.android_team3.databinding.CategoryItemBinding

class CategoryViewHolder(val binding: CategoryItemBinding): RecyclerView.ViewHolder(binding.root)