package com.bitc.springapp.dto;

import lombok.Data;

@Data
public class UserLoginDto {
    private String id;
    private String pw;
}
