package com.bitc.springapp.dto;

import lombok.Data;
@Data
public class BasketDTO {
    private int pdIdx;
    private String pdCd;
    private String pdName;
    private int pdJeongGa;
    private int pdDiscount;
    private int pdPrice;
    private int pdCnt;
    private String pdCreateDate;
    private String pdId;

}
